MATERIAL FOUNDRY EXPORT
=======================

Material      : Castle Ashlar
Family        : Stone Block Wall
Preset        : castle_ashlar
Seed          : 1042
Resolution    : 512 x 512 px (generated natively at this resolution, not upscaled)
Normal format : OpenGL
Generated     : 2026-10-21T15:43:24.219Z

All maps tile seamlessly in both directions. They were generated procedurally from the same
underlying material fields with periodic (toroidal) sampling.

FILES
-----
  stone_wall_seed_1042_basecolor_512.png                   Base Color
  stone_wall_seed_1042_normal_opengl_512.png               Normal
  stone_wall_seed_1042_roughness_512.png                   Roughness
  stone_wall_seed_1042_metallic_512.png                    Metallic
  stone_wall_seed_1042_height_16bit_512.png                Height
  stone_wall_seed_1042_ao_512.png                          Ambient Occlusion
  stone_wall_seed_1042_orm_512.png                         ORM (packed)
  settings.json                                            Material settings (re-importable into Material Foundry)
  README.txt                                               This file

MAP DETAILS
-----------
Base Color  : 8-bit sRGB color. Contains no baked lighting, shadows or preview light direction.
Normal      : 8-bit tangent-space normal, OpenGL (Y+): green points up (+V). Used by Blender, Godot, Unity, three.js, glTF.
              Derived from the height field with periodic central differences.
              Encoding: channel = (n * 0.5 + 0.5) * 255. Treat as non-color (linear) data.
Roughness   : 8-bit grayscale, non-color data. Perceptual roughness (0 smooth .. 1 rough).
Metallic    : 8-bit grayscale, non-color data. 0 = dielectric, 1 = metal.
Height      : 16-bit grayscale PNG, non-color data. 0 = lowest, 65535 = highest.
              True 16-bit samples are stored (PNG bit depth 16).
              Relief depth used for the normal map: 3.00% of the tile width
              (e.g. 6.0 cm for a 2 m tile). Use this as a starting
              displacement scale.
AO          : 8-bit grayscale, non-color data. HEIGHT-BASED APPROXIMATION: recesses are darkened
              according to how far they sit below their surroundings at several radii. It is not a
              ray-traced or physically simulated occlusion bake.
Emissive    : not applicable for this material (no emissive map exported).
ORM         : Packed 8-bit RGB, non-color data: R = Ambient Occlusion, G = Roughness, B = Metallic.
              Matches glTF / Unreal "ORM" conventions (glTF uses G and B; AO in R).

SUGGESTED PBR CONNECTIONS
-------------------------
Blender (Principled BSDF):
  Base Color  -> Base Color            (Color Space: sRGB)
  Roughness   -> Roughness             (Color Space: Non-Color)
  Metallic    -> Metallic              (Color Space: Non-Color)
  Normal      -> Normal Map node (Tangent Space) -> Normal   (Non-Color, OpenGL export)
  Height      -> Displacement node -> Material Output Displacement (Non-Color)
  Emissive    -> Emission Color, Emission Strength = suggested value above
  AO          -> optional: multiply into Base Color for stylized looks, or use in game engines
Unreal Engine: use the DirectX normal export (or flip green), set Roughness/Metallic/AO/ORM
  textures to "Masks (no sRGB)", Normal to "Normalmap".
Unity (URP/HDRP Lit): OpenGL normals, mark Normal as "Normal map"; Metallic map uses R (metal)
  and A (smoothness = 1 - roughness) - build a mask map if needed.
Godot: OpenGL normals; ORM texture can be used directly with ORMMaterial3D.

PRECISION NOTES
---------------
- All maps are lossless PNG. Color maps are 8-bit per channel.
- Normal map is 8-bit per channel; very gentle slopes are quantized to 1/127 steps.
- Height is 16-bit as stated above.
- Fine-detail noise octaves are limited by the Nyquist frequency of the export resolution, so
  higher resolutions contain additional fine detail rather than upscaled pixels.

MATERIAL SETTINGS
-----------------
  Stone color                  #8f887c
  Stone variation              #6d685f
  Mortar color                 #4f4a43
  Layout                       ashlar
  Courses                      5
  Blocks per course            3
  Stone count                  6
  Irregularity                 0.45
  Mortar width                 0.4
  Mortar depth                 0.7
  Stylized ↔ Natural           1
  Relief strength              1
  Detail intensity             0.55
  Roughness bias               0.5
  Face unevenness              0.5
  Color variation              0.5
  Chips & edge wear            0.45
  Crack density                0.25
  Crack width                  0.35
  Dirt in recesses             0.35
