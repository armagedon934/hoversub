MATERIAL FOUNDRY EXPORT
=======================

Material      : Molten Lava Crust
Family        : Lava / Emissive Cracked Rock
Preset        : molten_crust
Seed          : 1815
Resolution    : 512 x 512 px (generated natively at this resolution, not upscaled)
Normal format : OpenGL
Generated     : 2026-11-04T15:30:11.628Z

All maps tile seamlessly in both directions. They were generated procedurally from the same
underlying material fields with periodic (toroidal) sampling.

FILES
-----
  lava_rock_seed_1815_basecolor_512.png                    Base Color
  lava_rock_seed_1815_normal_opengl_512.png                Normal
  lava_rock_seed_1815_roughness_512.png                    Roughness
  lava_rock_seed_1815_metallic_512.png                     Metallic
  lava_rock_seed_1815_height_16bit_512.png                 Height
  lava_rock_seed_1815_ao_512.png                           Ambient Occlusion
  lava_rock_seed_1815_emissive_512.png                     Emissive
  lava_rock_seed_1815_orm_512.png                          ORM (packed)
  settings.json                                            Material settings (re-importable into Material Foundry)
  README.txt                                               This file

MAP DETAILS
-----------
Base Color  : 8-bit sRGB color. Contains no baked lighting, shadows or preview light direction.
Normal      : 8-bit tangent-space normal, OpenGL (Y+): green points up (+V). Used by Blender, Godot, Unity, three.js, glTF.
              Derived from the height field with periodic central differences.
              Encoding: channel = (n * 0.5 + 0.5) * 255. Treat as non-color (linear) data.
Roughness   : 8-bit grayscale, non-color data. Perceptual roughness (0 smooth .. 1 rough).
Metallic    : 8-bit grayscale, non-color data. 0 = dielectric, 1 = metal.
Height      : 16-bit grayscale PNG, non-color data. 0 = lowest, 65535 = highest.
              True 16-bit samples are stored (PNG bit depth 16).
              Relief depth used for the normal map: 4.00% of the tile width
              (e.g. 8.0 cm for a 2 m tile). Use this as a starting
              displacement scale.
AO          : 8-bit grayscale, non-color data. HEIGHT-BASED APPROXIMATION: recesses are darkened
              according to how far they sit below their surroundings at several radii. It is not a
              ray-traced or physically simulated occlusion bake.
Emissive    : 8-bit sRGB color at unit strength. Suggested emission strength: 4.00.
              Emission is present only in the intended regions (cracks / inlays).
ORM         : Packed 8-bit RGB, non-color data: R = Ambient Occlusion, G = Roughness, B = Metallic.
              Matches glTF / Unreal "ORM" conventions (glTF uses G and B; AO in R).

SUGGESTED PBR CONNECTIONS
-------------------------
Blender (Principled BSDF):
  Base Color  -> Base Color            (Color Space: sRGB)
  Roughness   -> Roughness             (Color Space: Non-Color)
  Metallic    -> Metallic              (Color Space: Non-Color)
  Normal      -> Normal Map node (Tangent Space) -> Normal   (Non-Color, OpenGL export)
  Height      -> Displacement node -> Material Output Displacement (Non-Color)
  Emissive    -> Emission Color, Emission Strength = suggested value above
  AO          -> optional: multiply into Base Color for stylized looks, or use in game engines
Unreal Engine: use the DirectX normal export (or flip green), set Roughness/Metallic/AO/ORM
  textures to "Masks (no sRGB)", Normal to "Normalmap".
Unity (URP/HDRP Lit): OpenGL normals, mark Normal as "Normal map"; Metallic map uses R (metal)
  and A (smoothness = 1 - roughness) - build a mask map if needed.
Godot: OpenGL normals; ORM texture can be used directly with ORMMaterial3D.

PRECISION NOTES
---------------
- All maps are lossless PNG. Color maps are 8-bit per channel.
- Normal map is 8-bit per channel; very gentle slopes are quantized to 1/127 steps.

- Height is 16-bit as stated above.
- Fine-detail noise octaves are limited by the Nyquist frequency of the export resolution, so
  higher resolutions contain additional fine detail rather than upscaled pixels.

MATERIAL SETTINGS
-----------------
  Crust color                  #2b2624
  Ash highlight                #5a514b
  Glow color                   #ff5a14
  Glow intensity               4
  Heat coverage                0.75
  Glow spread                  0.3
  Crust plates                 6
  Crack width                  0.5
  Secondary cracks             0.5
  Stylized ↔ Natural           1
  Relief strength              1
  Detail intensity             0.55
  Roughness bias               0.5
