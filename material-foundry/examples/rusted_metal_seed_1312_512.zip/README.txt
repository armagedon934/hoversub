MATERIAL FOUNDRY EXPORT
=======================

Material      : Corroded Steel Plate
Family        : Rusted Metal
Preset        : corroded_plate
Seed          : 1312
Resolution    : 512 x 512 px (generated natively at this resolution, not upscaled)
Normal format : OpenGL
Generated     : 2026-11-04T15:30:10.612Z

All maps tile seamlessly in both directions. They were generated procedurally from the same
underlying material fields with periodic (toroidal) sampling.

FILES
-----
  rusted_metal_seed_1312_basecolor_512.png                 Base Color
  rusted_metal_seed_1312_normal_opengl_512.png             Normal
  rusted_metal_seed_1312_roughness_512.png                 Roughness
  rusted_metal_seed_1312_metallic_512.png                  Metallic
  rusted_metal_seed_1312_height_16bit_512.png              Height
  rusted_metal_seed_1312_ao_512.png                        Ambient Occlusion
  rusted_metal_seed_1312_orm_512.png                       ORM (packed)
  settings.json                                            Material settings (re-importable into Material Foundry)
  README.txt                                               This file

MAP DETAILS
-----------
Base Color  : 8-bit sRGB color. Contains no baked lighting, shadows or preview light direction.
Normal      : 8-bit tangent-space normal, OpenGL (Y+): green points up (+V). Used by Blender, Godot, Unity, three.js, glTF.
              Derived from the height field with periodic central differences.
              Encoding: channel = (n * 0.5 + 0.5) * 255. Treat as non-color (linear) data.
Roughness   : 8-bit grayscale, non-color data. Perceptual roughness (0 smooth .. 1 rough).
Metallic    : 8-bit grayscale, non-color data. 0 = dielectric, 1 = metal.
Height      : 16-bit grayscale PNG, non-color data. 0 = lowest, 65535 = highest.
              True 16-bit samples are stored (PNG bit depth 16).
              Relief depth used for the normal map: 0.80% of the tile width
              (e.g. 1.6 cm for a 2 m tile). Use this as a starting
              displacement scale.
AO          : 8-bit grayscale, non-color data. HEIGHT-BASED APPROXIMATION: recesses are darkened
              according to how far they sit below their surroundings at several radii. It is not a
              ray-traced or physically simulated occlusion bake.
Emissive    : not applicable for this material (no emissive map exported).
ORM         : Packed 8-bit RGB, non-color data: R = Ambient Occlusion, G = Roughness, B = Metallic.
              Matches glTF / Unreal "ORM" conventions (glTF uses G and B; AO in R).

SUGGESTED PBR CONNECTIONS
-------------------------
Blender (Principled BSDF):
  Base Color  -> Base Color            (Color Space: sRGB)
  Roughness   -> Roughness             (Color Space: Non-Color)
  Metallic    -> Metallic              (Color Space: Non-Color)
  Normal      -> Normal Map node (Tangent Space) -> Normal   (Non-Color, OpenGL export)
  Height      -> Displacement node -> Material Output Displacement (Non-Color)
  Emissive    -> Emission Color, Emission Strength = suggested value above
  AO          -> optional: multiply into Base Color for stylized looks, or use in game engines
Unreal Engine: use the DirectX normal export (or flip green), set Roughness/Metallic/AO/ORM
  textures to "Masks (no sRGB)", Normal to "Normalmap".
Unity (URP/HDRP Lit): OpenGL normals, mark Normal as "Normal map"; Metallic map uses R (metal)
  and A (smoothness = 1 - roughness) - build a mask map if needed.
Godot: OpenGL normals; ORM texture can be used directly with ORMMaterial3D.

PRECISION NOTES
---------------
- All maps are lossless PNG. Color maps are 8-bit per channel.
- Normal map is 8-bit per channel; very gentle slopes are quantized to 1/127 steps.

- Height is 16-bit as stated above.
- Fine-detail noise octaves are limited by the Nyquist frequency of the export resolution, so
  higher resolutions contain additional fine detail rather than upscaled pixels.

MATERIAL SETTINGS
-----------------
  Bare metal color             #8e9092
  Rust (light)                 #b0592b
  Rust (dark)                  #4b2a1b
  Rust coverage                0.62
  Corrosion scale              3
  Pitting                      0.6
  Flaking & build-up           0.55
  Run-off streaks              0.35
  Mill scale on metal          0.4
  Stylized ↔ Natural           1
  Relief strength              1
  Detail intensity             0.55
  Roughness bias               0.5
