﻿MATERIAL FOUNDRY + UNDERSTAND CODE - portable version
=====================================================

Runs on your own computer, offline, with no installation. Nothing is sent anywhere.
Code you open is NEVER executed.

HOW TO START
1. Unpack the whole ZIP into any folder.
2. Double-click:
   - Windows: Start-Windows.bat
   - macOS:   Start-Mac.command   (first time: right-click -> Open -> Open)
   - Linux:   Start-Linux.sh
3. Your browser opens the program. Keep the small black window open while you use it;
   close it to stop.

IF IT DOES NOT START
- Windows: if "Windows protected your PC" appears, click "More info" -> "Run anyway".
- macOS and Linux need Python 3 (python.org) or Node.js (nodejs.org).
- Chrome or Edge work best (they can save changes straight into your folder).

WHAT IS INSIDE
- app/       the program (a web page)
- portable/  a tiny local web server that only this computer can reach (127.0.0.1)
